# 📋 Lista de Presença Online — Sistema Personalizado

Sistema completo com:
- Formulário de confirmação de presença (nome, email, matrícula/ID)
- Armazenamento em **SQLite**
- Painel **admin** com autenticação (Basic Auth)
- Exportação para **CSV** e **Excel**
- **QR Code** para abrir a página de confirmação
- Registro de **IP** e **User-Agent**

## 🚀 Como rodar
1. **Baixe o projeto** e entre na pasta:
   ```bash
   cd lista-presenca-app
   ```
2. **Crie o arquivo `.env`** baseado no `.env.example`:
   ```bash
   cp .env.example .env
   # edite ADMIN_USER e ADMIN_PASSWORD se quiser
   ```
3. **Instale as dependências**:
   ```bash
   npm install
   ```
4. **Inicie o servidor**:
   ```bash
   npm start
   ```
5. Acesse:
   - Página pública: `http://localhost:3000/`
   - Painel admin: `http://localhost:3000/admin` (vai pedir login)

## 🔐 Login do Admin
Ajuste as variáveis no `.env`:
```env
ADMIN_USER=admin
ADMIN_PASSWORD=admin123
```

## 📦 Banco de Dados
- Usamos **SQLite** (arquivo `db.sqlite` na raiz por padrão).
- Mudar o caminho? Defina `DATABASE_FILE=./caminho/para/outro.sqlite` no `.env`.

## 📤 Exportação
- **CSV:** `GET /export/csv`
- **Excel:** `GET /export/xlsx`

## 🧾 QR Code
- A rota `GET /qr` gera um PNG que abre a página pública.
- Imprima o QR em cartazes para o público escanear.

## 🛠️ Personalizações rápidas
- Título do evento: defina `EVENTO_NOME` no `.env` (usado na rota `/saude`).
- Campos extras: adicione colunas na tabela `presencas` e ajuste o `INSERT` no `server.mjs`.

## 🌐 Deploy
- Funciona em qualquer host Node (Railway, Render, VPS, etc.).
- Se estiver atrás de proxy, o QR usará `x-forwarded-proto` para montar o URL corretamente.

## ⚠️ Observações
- O Basic Auth é simples e suficiente para usos internos. Para produção sensível, considere autenticação com sessões, JWT, etc.
- Faça backup do `db.sqlite` antes de atualizar/limpar.
