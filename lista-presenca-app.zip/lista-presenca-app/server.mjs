import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import QRCode from "qrcode";
import basicAuth from "basic-auth";
import sqlite3 from "sqlite3";
import { open } from "sqlite";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const EVENTO_NOME = process.env.EVENTO_NOME || "Evento";

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// --- Banco de Dados (SQLite) ---
const db = await open({
  filename: process.env.DATABASE_FILE || path.join(__dirname, "db.sqlite"),
  driver: sqlite3.Database
});

await db.exec(`CREATE TABLE IF NOT EXISTS presencas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  email TEXT,
  id_ref TEXT,
  horario_iso TEXT NOT NULL,
  ip TEXT,
  useragent TEXT
)`);

// --- Middleware de Autenticação (Basic Auth) ---
function adminAuth(req, res, next) {
  const user = basicAuth(req);
  const u = process.env.ADMIN_USER || "admin";
  const p = process.env.ADMIN_PASSWORD || "admin123";
  if (!user || user.name !== u || user.pass !== p) {
    res.set("WWW-Authenticate", 'Basic realm="Admin"');
    return res.status(401).send("Autenticação necessária.");
  }
  next();
}

// --- Utilitário ---
function clientIp(req) {
  return req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.connection.remoteAddress || req.ip;
}

// --- API ---
app.post("/api/confirm", async (req, res) => {
  try {
    const { nome, email, id_ref } = req.body || {};
    if (!nome || String(nome).trim().length === 0) {
      return res.status(400).json({ error: "Nome é obrigatório." });
    }
    const horario_iso = new Date().toISOString();
    const ip = clientIp(req);
    const useragent = req.headers["user-agent"] || "";
    await db.run(
      "INSERT INTO presencas (nome, email, id_ref, horario_iso, ip, useragent) VALUES (?,?,?,?,?,?)",
      [String(nome).trim(), email || null, id_ref || null, horario_iso, ip, useragent]
    );
    res.json({ ok: true, nome: String(nome).trim(), email: email || null, id_ref: id_ref || null, horario_iso });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao confirmar presença." });
  }
});

// Listagem (protegida)
app.get("/api/list", adminAuth, async (req, res) => {
  const rows = await db.all("SELECT * FROM presencas ORDER BY id DESC");
  res.json(rows);
});

// Export CSV (protegida)
app.get("/export/csv", adminAuth, async (req, res) => {
  const rows = await db.all("SELECT * FROM presencas ORDER BY id ASC");
  const header = ["id","nome","email","id_ref","horario_iso","ip","useragent"];
  const csvRows = [header.join(",")];
  for (const r of rows) {
    const vals = header.map(h => {
      let v = r[h];
      if (v is null || v === undefined) v = "";
      v = String(v).replaceAll('"', '""');
      if (v.includes(",") || v.includes("\"") || v.includes("\n")) {
        return `"${v}"`;
      }
      return v;
    });
    csvRows.push(vals.join(","));
  }
  const csv = csvRows.join("\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="presencas.csv"`);
  res.send(csv);
});

// Export Excel (protegida)
app.get("/export/xlsx", adminAuth, async (req, res) => {
  const { default: ExcelJS } = await import("exceljs");
  const rows = await db.all("SELECT * FROM presencas ORDER BY id ASC");
  const workbook = new ExcelJS.Workbook();
  const ws = workbook.addWorksheet("Presenças");
  ws.columns = [
    { header: "ID", key: "id", width: 10 },
    { header: "Nome", key: "nome", width: 32 },
    { header: "Email", key: "email", width: 30 },
    { header: "ID Ref", key: "id_ref", width: 20 },
    { header: "Horário (ISO)", key: "horario_iso", width: 28 },
    { header: "IP", key: "ip", width: 20 },
    { header: "User Agent", key: "useragent", width: 60 }
  ];
  rows.forEach(r => ws.addRow(r));
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", 'attachment; filename="presencas.xlsx"');
  await workbook.xlsx.write(res);
  res.end();
});

// QR Code que aponta para a página de confirmação
app.get("/qr", async (req, res) => {
  try {
    const proto = req.headers["x-forwarded-proto"] || req.protocol || "http";
    const host = req.headers.host;
    const url = `${proto}://${host}/`;
    const png = await QRCode.toBuffer(url, { width: 512, margin: 2 });
    res.setHeader("Content-Type", "image/png");
    res.send(png);
  } catch (e) {
    console.error(e);
    res.status(500).send("Erro ao gerar QR Code");
  }
});

// Página admin (protegida)
app.get("/admin", adminAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

app.get("/saude", (req, res) => res.json({ status: "ok", evento: EVENTO_NOME }));

app.listen(PORT, () => {
  console.log(`✔ Servidor rodando em http://localhost:${PORT}`);
});
